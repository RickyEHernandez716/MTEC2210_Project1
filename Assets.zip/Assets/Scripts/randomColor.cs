using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class randomColor : MonoBehaviour
{
    //Calls the MeshRenderer from unity while making it public to access it. 
    public SpriteRenderer gameObjectSR;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        //if spacebar is pressed = ColorChange
        if (Input.GetKeyDown(KeyCode.Space))
        {
            //Call function made to change color
            changeColorOnSpace();

        }

    }
    //Function made to change color calling the variable from the Meshrender and going through its material and color properties to change color
    void changeColorOnSpace()
    {
        gameObjectSR.color = Random.ColorHSV();

    }


}